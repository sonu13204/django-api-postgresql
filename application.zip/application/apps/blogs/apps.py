from django.apps import AppConfig


class BlogsConfig(AppConfig):
    name = 'apps.blogs'
